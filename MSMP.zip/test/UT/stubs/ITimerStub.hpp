#pragma once

namespace stubs
{

class ITimerStub
{
public:
    virtual void run() = 0;
};

} // namespace stubs