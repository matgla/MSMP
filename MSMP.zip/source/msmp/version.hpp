#pragma once

#include <cstdint>

namespace msmp
{

constexpr uint8_t protocol_version_major = 0;
constexpr uint8_t protocol_version_minor = 1;

} // namespace msmp
