#pragma once

namespace msmp
{
namespace layers
{
namespace datalink
{
namespace receiver
{

class DataLinkReceiverSm;
class DataLinkReceiver;

} // namespace receiver
} // namespace datalink
} // namespace layers
} // namespace msmp
