#pragma once

namespace msmp
{
namespace layers
{
namespace datalink
{
namespace receiver
{

class Idle;
class ReceivingByte;
class ReceivingEscapedByte;

} // namespace receiver
} // namespace datalink
} // namespace layers
} // namespace msmp
