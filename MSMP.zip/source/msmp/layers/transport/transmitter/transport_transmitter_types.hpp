#pragma once

#include <cstdint>

#include <eul/container/static_vector.hpp>
#include <eul/container/static_deque.hpp>
#include <eul/function.hpp>

#include "msmp/configuration/configuration.hpp"
#include "msmp/message_type.hpp"
#include "msmp/types.hpp"

namespace msmp
{
namespace layers
{
namespace transport
{
namespace transmitter
{

using CallbackType = eul::function<void(), sizeof(void*)>;
using FrameBuffer = eul::container::static_vector<uint8_t, configuration::Configuration::max_payload_size>;
using ControlFrameBuffer = eul::container::static_vector<uint8_t, configuration::Configuration::max_control_message_size>;

template <typename Buffer>
struct FrameBase
{
    Buffer buffer;
    CallbackType on_success;
    CallbackType on_failure;
    uint8_t transaction_id;
    MessageType type;
};
using Frame = FrameBase<FrameBuffer>;
using ControlFrame = FrameBase<ControlFrameBuffer>;
using FrameQueue = eul::container::static_deque<Frame, configuration::Configuration::tx_buffer_frames_size>;
using ControlFrameQueue = eul::container::static_deque<ControlFrame, configuration::Configuration::tx_buffer_frames_size>;

} // namespace transmitter
} // namespace transport
} // namespace layers
} // namespace msmp
