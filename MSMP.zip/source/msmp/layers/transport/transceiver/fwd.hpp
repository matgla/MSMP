#pragma once

namespace msmp
{
namespace layers
{
namespace transport
{
namespace transceiver
{

class ITransportTransceiver;

} // namespace transceiver
} // namespace transport
} // namespace layers
} // namespace msmp
